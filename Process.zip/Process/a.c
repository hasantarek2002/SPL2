#include<stdio.h>


int main(){
	int i=0;

	printf("hello\n");

	/*
	for(i=0;;i++){
		printf("hello\n");

	}
	*/
	
}
