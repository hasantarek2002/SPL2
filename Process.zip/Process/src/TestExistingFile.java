import java.io.File;


public class TestExistingFile {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		File f = new File("/home/hasan/Desktop/a");
		if(f.exists() && !f.isDirectory()) { 
		    System.out.println("file found");
		}else{
			System.out.println("file not found");
		}

	}

}
