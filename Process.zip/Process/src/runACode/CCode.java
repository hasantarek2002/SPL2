package runACode;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

///////////////////////4-2-2018/////////////////////
///////////////////////////////////////////////////
// This code only take a c source file in a specified directory(Hard coded) named(/home/hasan/Desktop/a.c)
// then compiles it in a specified directory(Hard coded) named(/home/hasan/Desktop/a)
//  it does not handle Infinity Loop, TLE, input from a inputtedText file, malicious code, write or Wrong Answer
//// It just compile and execute a code 
// output will be in (codeOutput.txt) file  JUST printed Text(printf() format)

public class CCode {

	public static void main(String[] args) throws InterruptedException {

		String lan = "c";
		// String lan="cpp";
		String inputPath = "/home/hasan/Desktop/a.c";
		// String inputPath="/home/hasan/Desktop/aa.txt";
		boolean a = compile(inputPath, lan);
		if (a == true) {
			System.out.println("compile success");
			executeCode();

		} else {
			System.out.println("compile error");
		}

	}

	public static boolean compile(String path, String l)
			throws InterruptedException {
		System.out.println("Code compilation started...");
		ProcessBuilder p;

		boolean compiled = true;
		if (l.equals("c")) {
			String[] list = { "gcc", "-o", "/home/hasan/Desktop/a", path };
			p = new ProcessBuilder(list);
		} else {
			System.out.println("not a c program");
			return false;
			// p = new ProcessBuilder("g++","-std=c++0x","-w", "-o", "Main",
			// "Main("+username+").cpp");
		}

		// p.directory(new File(System.getProperty("dir")));
		// p.redirectErrorStream(true);

		try {
			Process pp = p.start();
			pp.waitFor();
			return isfFileFound("/home/hasan/Desktop/a");

			/*
			 * InputStream is = pp.getInputStream(); String temp; try {
			 * BufferedReader b = new BufferedReader(new InputStreamReader(is));
			 * while ((temp = b.readLine()) != null) { compiled = false;
			 * System.out.println(temp); } pp.waitFor(); }catch(Exception e){
			 * System.out.println(e); }
			 * 
			 * if (!compiled) { is.close();
			 * //System.out.println("compile error"); return false; }
			 * is.close(); //System.out.println("compile success"); return true;
			 */

		} catch (IOException e) {
			System.out.println("in compile() " + e);
		}

		// System.out.println("compile error");
		return false;
	}

	public static boolean isfFileFound(String path) {
		File f = new File(path);
		if (f.exists() && !f.isDirectory()) {
			return true;
		}
		return false;
	}

	public static void executeCode() {
		try {
			String[] list = { "/home/hasan/Desktop/a" }; // this is the object
															// file path
			ProcessBuilder pb = new ProcessBuilder(list);
			Process p = pb.start();
			BufferedReader br = new BufferedReader(new InputStreamReader(
					p.getInputStream()));
			BufferedWriter bw = new BufferedWriter(new FileWriter(new File(
					"codeOutput.txt")));
			String line;
			while ((line = br.readLine()) != null) {
				bw.write(line);
			}
			bw.close();
		} catch (Exception ex) {
			System.out.println(ex);
		}

	}

}
