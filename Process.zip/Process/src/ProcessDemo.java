import java.io.BufferedReader;
import java.io.InputStreamReader;

public class ProcessDemo {

   public static void main(String[] args) {

      System.out.println
         ("*************Calendar for Year**********");
      try {
    	  String[] list = {"cal", "2022"};
         ProcessBuilder pb = new
            ProcessBuilder(list);
         Process p=pb.start();
         BufferedReader br=new BufferedReader(
            new InputStreamReader(
               p.getInputStream()));
            String line;
            while((line=br.readLine())!=null){
               System.out.println(line);
            }
      } catch (Exception ex) {
         System.out.println(ex);
      }
      System.out.println
         ("************************************");
   }
}