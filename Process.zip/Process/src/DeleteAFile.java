import java.io.File;
import java.nio.file.Files;


public class DeleteAFile {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		File f = new File("/home/hasan/Desktop/a");
		if(f.exists() && !f.isDirectory()) { 
			System.out.println("file found");
			f.delete();
			System.out.println("file deleted");
		}else{
			System.out.println("file not found");
		}
		

	}

}
